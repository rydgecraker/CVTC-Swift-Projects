#!/bin/sh

#  Script.sh
#  GiftLister
#
#  Created by George Andrews on 1/16/17.
#  Copyright © 2017 Ray Wenderlich. All rights reserved.

rm /Users/$(whoami)/Library/Developer/CoreSimulator/Devices/*/data/Containers/Data/Application/*/Library/Application\ Support/GiftLister.sqlite

//
//  Extensions.swift
//  PetFinder
//
//  Created by Luke Parham on 8/31/15.
//  Copyright © 2015 Luke Parham. All rights reserved.
//

import UIKit

extension UIImageView {
  
  func loadURL(_ url: URL?) {
    guard let url = url else {
      return
    }
    
    let urlRequest = URLRequest(url: url)
    
    URLSession.shared.dataTask(with: urlRequest, completionHandler: { (data, response, error) -> Void in
      if let response = response, let data = data, response.isHTTPResponseValid() {
        DispatchQueue.main.async(execute: { () -> Void in
          if UIImage(data: data) == nil {
            self.image = UIImage(named: "standardCat")
          } else {
            self.image = UIImage(data: data)
          }
        })
      }
      }) .resume()
  }
  
}

extension URLResponse {
  func isHTTPResponseValid() -> Bool {
    guard let response = self as? HTTPURLResponse else {
      return false
    }
    
    return (response.statusCode >= 200 && response.statusCode <= 299)
  }
}

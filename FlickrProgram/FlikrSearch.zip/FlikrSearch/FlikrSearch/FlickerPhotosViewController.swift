//
//  FlickerPhotosViewController.swift
//  FlikrSearch
//
//  Created by Craker, Rydge on 2/1/18.
//  Copyright © 2018 Craker, Rydge. All rights reserved.
//

import UIKit


final class FlickerPhotosViewController: UICollectionViewController {

    //MARK: - Properties
    fileprivate let reuseIdentifier = "FlickrCell"
    
    //Set up the inset distances for the views
    fileprivate let sectionInsets = UIEdgeInsets(top: 50.0, left: 20.0, bottom: 50.0, right: 20.0)

    //Array that will keep track of all the searches made in the app
    fileprivate var searches = [FlickrSearchResults]()
    
    //Instantiate the Flickr class. The Flickr instance will do the searching for you...
    fileprivate let flickr = Flickr()
 
    fileprivate let itemsPerRow: CGFloat = 3.0
}


//MARK: - Private Extension
private extension FlickerPhotosViewController {
    
    //Helper method that will get a specific photo related to an indexPath in your collection view.
    //This is an often repeated task, so we'll make a function for it.
    //
    //IndexPath: a list of indexes that together represent the path to a specific location in a tree of nested arrays
    func photoForIndexPath(indexPath: IndexPath) -> FlickrPhoto {
        
        return searches[indexPath.section].searchResults[indexPath.row]
        
    }
    
}


extension FlickerPhotosViewController: UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        //Add an activity view
        //
        //UIActivityIndicatorView: a view that shows a task that is in progress
        let activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: .gray)
        
        //Add a view (UIActivityIndicatorVIew) to teh end of teh reciever's list of subviews
        textField.addSubview(activityIndicator)
        
        //Use the textField's frame (bounding rect) to define the frame rect of the activity indicator
        activityIndicator.frame = textField.bounds
        
        //Start the animation of the progress indicator
        activityIndicator.startAnimating()
        
        //Use the provided Flickr class to search Flickr for photos that match the given search term asynchronously.
        //When the search completes, the completion code block below will be called with the result set of FlickerPhoto Objects and any errors, if one occured.
        flickr.searchFlickrForTerm(textField.text!) {
            results, error in
            
            //Unlink the view from its super view and its window and removes it from the responder view
            activityIndicator.removeFromSuperview()
            
            //Log any errors to console (should only be done in development mode)
            if let error = error {
                print("Error Searching: \(error)")
                return
            }
            
            if let results = results {
                
                //The results get logged and added to the front of the searches array (via insert)
                print("Found \(results.searchResults.count) matching \(results.searchTerm)")
                
                self.searches.insert(results, at: 0)
                
                //Self.collectionView is the collectionView object managed by this view controller
                //At this point, you have new data and thus need to refresh the UI, so reload all data for the collection view
                self.collectionView?.reloadData()
            }
            
        }
        
        textField.text = nil
        textField.resignFirstResponder()
        return true
        
    }
    
}

//Implement the UICollectionViewDataSource and UICollecitonViewDelegateFlowLayout methods on your view controller via extensions


//MARK: - UICollectionViewDataSource
extension FlickerPhotosViewController {
    
    //There is one search per section, so the number of sections is the number of elements in the "searches" array
    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        return searches.count
    }
    
    //Number of items in a section, which is the count of the searchResults array from the relevant FlickrSearch obejct -> i.e. number of pics
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return searches[section].searchResults.count
    }
    
    //Populate and configure a CollectionView Cell
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath)
        cell.backgroundColor = UIColor.black
        return cell
    }
    
}



//MARK: - UICollectionViewDelegateFlowLayout
extension FlickerPhotosViewController: UICollectionViewDelegateFlowLayout {
    
    //Tell the layout (object) the size of the given cell
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        //Work out the total amount of space taken up by padding.
        //There will be n+1 evenly sized spaces; where n is the number of items in a row
        //The space size can be taken from the left section inset
        let paddingSpace = sectionInsets.left * (itemsPerRow + 1)
        
        //Subtract the padding space from the view's width and dividing by the number of items in a row gives you the width (and height) for each item. (The size will be returned as a square)
        
        let avaliableWidth = view.frame.width - paddingSpace
        let widthPerItem = avaliableWidth / itemsPerRow
        
        return CGSize(width: widthPerItem, height: widthPerItem)
        
    }
    
    
    //Return the spacing between the cells, headers, and footers. This is where we use our section insets constant value.
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return sectionInsets
    }
    
    //Control the spacing between each line/row in the layout. We want this to match the padding at the left and right
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return sectionInsets.left
    }
    
}

